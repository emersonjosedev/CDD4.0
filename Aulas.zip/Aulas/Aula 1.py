an = int(input("sua idade?"))

print(f" voce nasceu em {2023 - an}")

if an >= 18:
    print("Voce e de maior")

#######################
n1 = int(input("Escolha um numero."))
n2 = int(input("Escolha um numero."))
n3= int(input("Escolha um numero."))

if n1 > n2:
    if n1 > n3:
        print("N1 e maior")
elif n2 > n3:
    print("N3 e o maior")
else:
    print("N3 é o maior")

##########################



