for x in range (-50, 51, 1):
    print(x, end= "")

for y in range(1,101,1):
    print(y)

for x in range(100, 0,-1):
    print(x)