numero = int("Digite um numero entre 1 e 12")

if numero <1 or numero >12:
    print("Invalido")
elif numero == 2:
    print("Janeiro")
elif numero == 2:
    print("Fevereiro")
elif numero == 3:
    print("março")
elif numero == 4:
    print("Abril")
elif numero == 5:
    print("Maio")
elif numero == 6:
    print("Junho")
elif numero == 7:
    print("Julho")
elif numero == 8:
    print("Agosto")
elif numero == 9:
    print("Setembro")
elif numero == 10:
    print("Outubro")
elif numero == 11:
    print("Novembro")
else:
    print("Dezembro")


