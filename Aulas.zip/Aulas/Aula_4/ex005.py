soma = 0

for x in range(10):
    n1 = int(input("Escreva"))
    soma = soma + n1
    print(x, end= "")

