aluno = input("Qual o seu nome? ")
n = float(input("Digite a nota "))
n2 = float(input("Digite a nota "))
m = (n + n2 ) / 2
print(f"Hola {aluno}! sua média é {m}")