n1 = float(input("Escreva um número"))
n2 = float(input("Escreva um número"))




if n1 < n2:
    print(f"{n2}\n {n1}")

else:
    if n1 < n2:
        print(f"{n1}\n {n2}")

    else:
        print(f"{n2} \n {n1}")


