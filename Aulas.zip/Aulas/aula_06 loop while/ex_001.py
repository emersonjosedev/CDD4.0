x = 1

while x < 11:
    print(x)
    x += 1
