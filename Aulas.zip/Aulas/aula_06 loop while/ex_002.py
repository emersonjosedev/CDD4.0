r = 1
soma = 0
repetir = int(input("Quantos alunos"))

while r <= repetir:
    n = float(input("Digite a nota\n"))
    soma = soma + n
    r +=1
m = n / repetir
print(m)