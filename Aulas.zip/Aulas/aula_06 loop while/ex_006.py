num = int(input("Digite um número"))
for x in range(1,num + 1):
    for x in range(5):
         print( x,num, end="\n")
print(".....")
