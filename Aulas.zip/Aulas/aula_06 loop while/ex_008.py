numero = int(input("Digite um numero"))
contador = 0
while  contador < numero :
    print(str(contador) * contador, end="")
    contador += 1


