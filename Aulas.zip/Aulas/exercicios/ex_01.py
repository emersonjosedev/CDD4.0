'''Crie um programa que mostre o nome de tres pessoas '''

usuario = input("Digite seu nome: \n")
usuario2 = input("Digite seu nome: \n")
usuario3= input("Digite seu nome: \n")

print(f"\n o nome do user 1 é {usuario}\n o do usuario 2 é {usuario2}\n o usuario 3 é {usuario3}")




