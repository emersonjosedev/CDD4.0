n =int( input("Digite um número"))
n2 = int(input("Digite um número"))
r = n + n2
ele = print(r)

while True:
    print(ele)
