for x in range(101,112,1):
    print(x)