recebe = int(input("Digite"))

for x in range(100 ,101+ recebe,1):
    print(x)