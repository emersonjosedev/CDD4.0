for x in range(1,10,1):
    print(x, end= " ")

for y in range(10,0,-1):
    print(y, end= " ")

