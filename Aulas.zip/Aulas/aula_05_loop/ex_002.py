tabuada  = int(input("Digite um número\n"))

for x in range(0,11,1):
    num = tabuada * x
    print(f" {tabuada} x {x} = {num}")







